package notebook.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import notebook.entity.IUserDao;
import notebook.entity.User;

/**
 * Implements the IUserDao interface.
 */
public class UserDaoImpl implements IUserDao {

	private static UserDaoImpl instance = new UserDaoImpl();

	public static UserDaoImpl getInstance() {
		return instance;
	}

	private static final Logger LOG = Logger.getLogger(UserDaoImpl.class);
	private static final String PROP_DRIVER = "driver";
	private static final String PROP_PROTOCOL = "protocol";
	private static final String PROP_DATABASE = "database";
	private static final String DATABASE_PROPERTIES = "build.properties";

	/** Gets the connection to the database. 
	 *  
	 *  @return Connection to database.
	 *  @throws RuntimeException if database is not available. 
	 */
	private Connection getConnection() {
		Connection connection = null;
		Properties props = new Properties();

		try {
			props.load(UserDaoImpl.class.getClassLoader().getResourceAsStream(
					DATABASE_PROPERTIES));

			String driver = props.getProperty(PROP_DRIVER);
			String database = props.getProperty(PROP_PROTOCOL) + props.getProperty(PROP_DATABASE);

			Class.forName(driver).newInstance();

			connection = DriverManager.getConnection(database, props);
		} catch (Exception ex) {
			LOG.error("Error connecting to database: " + PROP_DATABASE, ex);
			throw new RuntimeException("Database " + PROP_DATABASE
					+ " is not available.", ex);
		}
		return connection;
	}

	/**
	 * Returns a list of users from database.
	 * 
	 * @return The list of users.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	@Override
	public List<User> read() {
		List<User> userList = new ArrayList<User>();

		Connection conn = getConnection();
		Statement s = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			s = conn.createStatement();
			rs = s.executeQuery("SELECT * FROM APP.USERS ORDER BY ID ASC");

			LOG.debug("Results of select * from app.users order by id asc query - reading users.");
			while (rs.next()) {

				LOG.debug("  " + rs.getString("ID") + " "
						+ rs.getString("SURNAME") + " " + rs.getString("NAME")
						+ " " + rs.getString("AGE") + " " + rs.getString("SEX")
						+ " " + rs.getString("TELEPHONE"));
				User user = new User();
				user.setId(rs.getInt("ID"));
				user.setSurname(rs.getString("SURNAME"));
				user.setName(rs.getString("NAME"));
				user.setAge(rs.getInt("AGE"));
				user.setSex(rs.getString("SEX").charAt(0));
				user.setTelephone(rs.getString("TELEPHONE"));
				userList.add(user);
			}
		} catch (Exception ex) {
			LOG.error("Really bad database error - reading users.", ex);
		} finally {
			try {
				rs.close();
				s.close();
				conn.commit();
				conn.close();
			} catch (SQLException e) {
				LOG.error("More really bad database errors - reading users.", e);
			}
		}

		return userList;
	}

	/**
	 * Returns a list of users found in database by criteria.
	 * 
	 * @param surname Surname of user.
	 * @param name Name of user.
	 * @param age Age of user.
	 * @param sex Sex of user.
	 * @param telephone Telephone of user.
	 * @return The list of users.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	@Override
	public List<User> find(String surname, String name, Integer age,
			Character sex, String telephone) {
		List<User> findList = new ArrayList<User>();

		Connection conn = getConnection();
		Statement s = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			s = conn.createStatement();
			rs = s.executeQuery("SELECT * FROM APP.USERS");

			LOG.debug("Results of select * from app.users query - finding users.");
			while (rs.next()) {

				LOG.debug("  " + rs.getString("ID") + " "
						+ rs.getString("SURNAME") + " " + rs.getString("NAME")
						+ " " + rs.getString("AGE") + " " + rs.getString("SEX")
						+ " " + rs.getString("TELEPHONE"));

				if (((surname == "") & (name == "") & (age == -1)
						& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						||

						((surname != "")
								& (rs.getString("SURNAME").indexOf(surname) != -1)
								& (name == "") & (age == -1)
								& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						|| ((surname != "")
								& (rs.getString("SURNAME").indexOf(surname) != -1)
								& (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age == -1)
								& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						|| ((surname != "")
								& (rs.getString("SURNAME").indexOf(surname) != -1)
								& (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age != -1) & (rs.getInt("AGE") == age)
								& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						|| ((surname != "")
								& (rs.getString("SURNAME").indexOf(surname) != -1)
								& (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age != -1) & (rs.getInt("AGE") == age)
								& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						|| ((surname != "")
								& (rs.getString("SURNAME").indexOf(surname) != -1)
								& (name == "") & (age == -1)
								& (rs.getString("SEX").charAt(0) == sex)
								& (telephone != "") & (rs
								.getString("TELEPHONE").indexOf(telephone) != -1))
						|| ((surname != "")
								& (rs.getString("SURNAME").indexOf(surname) != -1)
								& (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age == -1)
								& (rs.getString("SEX").charAt(0) == sex)
								& (telephone != "") & (rs
								.getString("TELEPHONE").indexOf(telephone) != -1))
						|| ((surname != "")
								& (rs.getString("SURNAME").indexOf(surname) != -1)
								& (name == "") & (age != -1)
								& (rs.getInt("AGE") == age)
								& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						|| ((surname != "")
								& (rs.getString("SURNAME").indexOf(surname) != -1)
								& (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age != -1) & (rs.getInt("AGE") == age)
								& (rs.getString("SEX").charAt(0) == sex)
								& (telephone != "") & (rs
								.getString("TELEPHONE").indexOf(telephone) != -1))
						||

						((surname == "") & (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age == -1)
								& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						|| ((surname == "") & (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age != -1) & (rs.getInt("AGE") == age)
								& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						|| ((surname == "") & (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age != -1) & (rs.getInt("AGE") == age)
								& (rs.getString("SEX").charAt(0) == sex)
								& (telephone != "") & (rs
								.getString("TELEPHONE").indexOf(telephone) != -1))
						|| ((surname == "") & (name != "")
								& (rs.getString("NAME").indexOf(name) != -1)
								& (age == -1)
								& (rs.getString("SEX").charAt(0) == sex)
								& (telephone != "") & (rs
								.getString("TELEPHONE").indexOf(telephone) != -1))
						||

						((surname == "") & (name == "") & (age != -1)
								& (rs.getInt("AGE") == age)
								& (rs.getString("SEX").charAt(0) == sex) & (telephone == ""))
						|| ((surname == "") & (name == "") & (age != -1)
								& (rs.getInt("AGE") == age)
								& (rs.getString("SEX").charAt(0) == sex)
								& (telephone != "") & (rs
								.getString("TELEPHONE").indexOf(telephone) != -1))
						||

						((surname == "") & (name == "") & (age == -1)
								& (rs.getString("SEX").charAt(0) == sex)
								& (telephone != "") & (rs
								.getString("TELEPHONE").indexOf(telephone) != -1))) {
					User user = new User();
					user.setId(rs.getInt("ID"));
					user.setSurname(rs.getString("SURNAME"));
					user.setName(rs.getString("NAME"));
					user.setAge(rs.getInt("AGE"));
					user.setSex(rs.getString("SEX").charAt(0));
					user.setTelephone(rs.getString("TELEPHONE"));
					findList.add(user);
				}
			}
		} catch (Exception ex) {
			LOG.error("Really bad database error - finding users.", ex);
		} finally {
			try {
				rs.close();
				s.close();
				conn.commit();
				conn.close();
			} catch (SQLException e) {
				LOG.error("More really bad database errors - finding users.", e);
			}
		}

		return findList;
	}

	/**
	 * Returns the user with the specified ID, or null if no such person exists.
	 * 
	 * @param id Identifier of user.
	 * @return The user.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	@Override
	public User read(int id) {
		User user = new User();

		Connection conn = getConnection();
		Statement s = null;
		ResultSet rs = null;

		try {
			conn = getConnection();
			s = conn.createStatement();
			rs = s.executeQuery("SELECT * FROM APP.USERS WHERE ID = " + id);

			while (rs.next()) {
				user.setId(rs.getInt("ID"));
				user.setSurname(rs.getString("SURNAME"));
				user.setName(rs.getString("NAME"));
				user.setAge(rs.getInt("AGE"));
				user.setSex(rs.getString("SEX").charAt(0));
				user.setTelephone(rs.getString("TELEPHONE"));
			}
		} catch (Exception ex) {
			LOG.error("Really bad database error - reading user.", ex);
		} finally {
			try {
				rs.close();
				s.close();
				conn.commit();
				conn.close();
			} catch (SQLException e) {
				LOG.error("More really bad database errors - reading user.", e);
			}
		}
		return user;
	}

	/**
	 * Stores the user in database.
	 * 
	 * @param user Instance of user.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	@Override
	public void save(User user) {
		User newUser = new User();
		newUser = user;

		String surname = newUser.getSurname();
		String name = newUser.getName();
		Integer age = newUser.getAge();
		Character sex = newUser.getSex();
		String telephone = newUser.getTelephone();

		Connection conn = getConnection();
		Statement s = null;

		try {
			conn = getConnection();
			s = conn.createStatement();
			s.executeUpdate("INSERT INTO APP.USERS VALUES (DEFAULT,'" + surname
					+ "','" + name + "'," + age + ",'" + sex + "','"
					+ telephone + "')");

		} catch (Exception ex) {
			LOG.error("Really bad database error - saving user.", ex);
		} finally {
			try {
				s.close();
				conn.commit();
				conn.close();
			} catch (SQLException e) {
				LOG.error("More really bad database errors - saving user.", e);
			}
		}
	}

	/**
	 * Updates the user in database.
	 * 
	 * @param user Instance of user.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	@Override
	public void update(User user) {
		User updateUser = new User();
		updateUser = user;

		int id = updateUser.getId();
		String surname = updateUser.getSurname();
		String name = updateUser.getName();
		Integer age = updateUser.getAge();
		Character sex = updateUser.getSex();
		String telephone = updateUser.getTelephone();

		Connection conn = getConnection();
		Statement s = null;

		try {
			conn = getConnection();
			s = conn.createStatement();
			s.executeUpdate("UPDATE APP.USERS SET SURNAME = '" + surname
					+ "', NAME = '" + name + "', AGE = " + age + ", SEX = '"
					+ sex + "', TELEPHONE = '" + telephone + "' WHERE ID = "
					+ id);
		} catch (Exception ex) {
			LOG.error("Really bad database error - updating user.", ex);
		} finally {
			try {
				s.close();
				conn.commit();
				conn.close();
			} catch (SQLException e) {
				LOG.error("More really bad database errors - updating user.", e);
			}
		}
	}

	/**
	 * Deletes the user from the database.
	 * 
	 * @param id Identifier of user.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	@Override
	public void delete(int id) {
		Connection conn = getConnection();
		Statement s = null;

		try {
			conn = getConnection();
			s = conn.createStatement();
			s.executeUpdate("DELETE FROM APP.USERS WHERE ID = " + id);
		} catch (Exception ex) {
			LOG.error("Really bad database error - deleting user.", ex);
		} finally {
			try {
				s.close();
				conn.commit();
				conn.close();
			} catch (SQLException e) {
				LOG.error("More really bad database errors - deleting user.", e);
			}
		}
	}
}

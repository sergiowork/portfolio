package notebook.service;

/**
 * Enum that represents the female or male sex.
 *
 */
public enum Sex {
	m,
	w;
}

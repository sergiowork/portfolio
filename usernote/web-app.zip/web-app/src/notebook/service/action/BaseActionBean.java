package notebook.service.action;

import net.sourceforge.stripes.action.ActionBean;
import net.sourceforge.stripes.action.ActionBeanContext; 

/**
 * Implements the ActionBean interface.
 * When you add an action bean, you can just extend BaseActionBean class and get on with your business. 
 * BaseActionBean is also the place to put any other common code that you might to reuse in all action beans.
 */
public abstract class BaseActionBean implements ActionBean {
	private ActionBeanContext actionBeanContext;

	/** Gets the actionBeanContext. */
    public ActionBeanContext getContext() {
        return actionBeanContext;
    }
    
    /** Sets the actionBeanContext. */
    public void setContext(ActionBeanContext actionBeanContext) {
        this.actionBeanContext = actionBeanContext;
    } 
}

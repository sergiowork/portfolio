package notebook.service.action;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import notebook.entity.User;
import notebook.service.UserDaoImpl;

/**
 * ActionBean that deals with finding users in database.
 */
public class UserFindActionBean extends BaseActionBean {
	/** Represents a page for finding users. */
	private static final String FIND = "/WEB-INF/jsp/find_form.jsp";

	/** List of users found in database by criteria. */
	private List<User> results = new ArrayList<User>();

	/** Gets the list of users found in database by criteria. */
	public List<User> getResults() {
		return results;
	}

	/** DefaultHandler, which is called when the user arrives at the page for finding users. */
	@DefaultHandler
	public Resolution search() {
		return new ForwardResolution(FIND);
	}

	/** Handler that gets the values from input fields, searches users in database and
	 *  represents result list of found users.
	 */
	public Resolution find() {
		String surname = getContext().getRequest().getParameter("surname")
				.trim();
		String name = getContext().getRequest().getParameter("name").trim();

		Integer age = -1;
		if (getContext().getRequest().getParameter("age").trim() != "")
			age = Integer.valueOf(getContext().getRequest().getParameter("age")
					.trim());

		Character sex = getContext().getRequest().getParameter("sex").charAt(0);
		String telephone = getContext().getRequest().getParameter("telephone")
				.trim();

		results.clear();
		results = UserDaoImpl.getInstance().find(surname, name, age, sex,
				telephone);

		return new ForwardResolution(FIND);
	}

	/** Handler that clears input fields on page for finding users. */
	public Resolution clear() {
		return new RedirectResolution(UserFindActionBean.class);
	}
}

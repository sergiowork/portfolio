package notebook.service.action;

import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.DontValidate;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.SimpleMessage;
import net.sourceforge.stripes.validation.Validate;
import net.sourceforge.stripes.validation.ValidateNestedProperties;
import notebook.entity.User;
import notebook.service.UserDaoImpl;

/**
 * ActionBean that deals with updating user in database.
 */
public class UserUpdateActionBean extends BaseActionBean {
	/** Represents a page for updating user. */
	private static final String UPDATE = "/WEB-INF/jsp/update_form.jsp";

	/** Represents the validate fields and event handler for which to apply required=true. */
	@ValidateNestedProperties({
			@Validate(field = "surname", required = true, minlength = 5, maxlength=30, on = "save"),
			@Validate(field = "name", required = true, minlength = 5, maxlength=15, on = "save"),
			@Validate(field = "age", required = true, minvalue = 1, on = "save"),
			@Validate(field = "sex", required = true, on = "save"),
			@Validate(field = "telephone", required = true, mask = "\\+\\(?\\d{3}\\)?\\ \\d{3}\\-\\d{2}\\-\\d{2}", on = "save") })
	
	/** Represent a user. */
	private User user;

	/** Gets the user which being updated. */
	public User getUser() {
		return user;
	}

	/** Sets the user which being updated. */
	public void setUser(User user) {
		this.user = user;
	}

	/** DefaultHandler, which is called when the user arrives at the page for update user. */
	@DefaultHandler
	public Resolution updateform() {
		return new ForwardResolution(UPDATE);
	}

	/** Handler that deals with population of data user input fields  and
	 *  redirect them to the update user page.
	 */
	public Resolution update() {		
		UserDaoImpl userDao = new UserDaoImpl();
		User updUser = new User();

		String id;
		if (getContext().getRequest().getParameter("userId") == "") {
			return new RedirectResolution(UserListActionBean.class);
		} else {
		  id = getContext().getRequest().getParameter("userId");
		}
		setUser(userDao.read(Integer.parseInt(id)));

		updUser.setId(this.user.getId());
		updUser.setSurname(this.user.getSurname().trim());
		updUser.setName(this.user.getName().trim());
		updUser.setAge(this.user.getAge());
		updUser.setSex(this.user.getSex());
		updUser.setTelephone(this.user.getTelephone().trim());

		return new ForwardResolution(UPDATE);
	}

	/** Handler that gets the values from input fields, updates user in database and
	 *  redirect them to the users list page.
	 */
	public Resolution save() {
		UserDaoImpl userDao = new UserDaoImpl();
		User updUser = new User(); 

		String id = getContext().getRequest().getParameter("user.id");
		updUser.setId(Integer.parseInt(id));
		updUser.setSurname(getContext().getRequest()
				.getParameter("user.surname").trim());
		updUser.setName(getContext().getRequest().getParameter("user.name")
				.trim());
		updUser.setAge(Integer.valueOf(getContext().getRequest()
				.getParameter("user.age").trim()));
		updUser.setSex(getContext().getRequest().getParameter("user.sex")
				.charAt(0));
		updUser.setTelephone(getContext().getRequest()
				.getParameter("user.telephone").trim());

		userDao.update(updUser);

		return new RedirectResolution(UserListActionBean.class);
	}

	/** Handler that cancels operation of delete user and
	 *  redirects them to the users list page.
	 */
	@DontValidate
	public Resolution cancel() {
		getContext().getMessages().add(
				new SimpleMessage("Action 'Update a user' cancelled."));
		return new RedirectResolution(UserListActionBean.class);
	}

}

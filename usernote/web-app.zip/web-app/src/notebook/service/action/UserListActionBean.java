package notebook.service.action;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.SimpleMessage;
import notebook.entity.IUserDao;
import notebook.entity.User;
import notebook.service.UserDaoImpl;

/**
 * ActionBean that deals with representing list of users and 
 * deleting user from database.
 */
public class UserListActionBean extends BaseActionBean {
	/** Represents a page for viewing users. */
	private static final String LIST = "/WEB-INF/jsp/user_list.jsp";

	/** Represents a IUserDao instance. */
	private IUserDao userDao = UserDaoImpl.getInstance();

	/** Gets the IUserDao instance. */
	private IUserDao getUserDao() {
		return userDao;
	}

	/** Represents a current identifier of user. */
	private Integer userId;

	/** Gets the current identifier of user. */
	public Integer getUserId() {
		return userId;
	}

	/** Sets the current identifier of user. */
	public void setUserId(Integer id) {
		userId = id;
	}

	/** Represent a user. */
	private User user;

	/** Gets the user which being deleted. */
	public User getUser() {
		if (userId != null) {
			return userDao.read(userId);
		}
		return user;
	}

	/** Gets the user which being deleted. */
	public void setUser(User user) {
		this.user = user;
	}

	/** List of all users from database. */
	private List<User> results = new ArrayList<User>();

	/** Gets the list of all users from database. */
	public List<User> getResults() {
		return results;
	}

	/** DefaultHandler, which is called when the user arrives at the page for viewing all users. */
	@DefaultHandler
	public Resolution list() {
		results.clear();
		results = UserDaoImpl.getInstance().read();

		return new ForwardResolution(LIST);
	}

	/** Handler that gets the value of current user id, asks user to confirm delete operation, deletes user from database and
	 *  redirect them to the users list page.
	 */
	public Resolution delete() {		
		UserDaoImpl userDao = new UserDaoImpl();
		
		int id;
		if (getContext().getRequest().getParameter("user.id") == "") {
			return new RedirectResolution(UserListActionBean.class);
		} else {
			id = Integer.parseInt(getContext().getRequest().getParameter("user.id"));
		}
		
		User deleted = getUserDao().read(id);
		userDao.delete(id);

		getContext().getMessages().add(
				new SimpleMessage("Deleted {0}", deleted));
		return new RedirectResolution(UserListActionBean.class);
	}
}

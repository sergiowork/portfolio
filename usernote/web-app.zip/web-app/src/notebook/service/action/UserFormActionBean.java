package notebook.service.action;

import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.DontValidate;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.SimpleMessage;
import net.sourceforge.stripes.validation.Validate;
import net.sourceforge.stripes.validation.ValidateNestedProperties;
import notebook.entity.User;
import notebook.service.UserDaoImpl;

/**
 * ActionBean that deals with adding user in database.
 */
public class UserFormActionBean extends BaseActionBean {
	/** Represents a page for adding user. */
	private static final String FORM = "/WEB-INF/jsp/user_form.jsp";

	/** Represents the validate fields and event handler for which to apply required=true. */
	@ValidateNestedProperties({
			@Validate(field = "surname", required = true, minlength = 5, maxlength=30, on = "save"),
			@Validate(field = "name", required = true, minlength = 5, maxlength=15, on = "save"),
			@Validate(field = "age", required = true, minvalue = 1, on = "save"),
			@Validate(field = "sex", required = true, on = "save"),
			@Validate(field = "telephone", required = true, mask = "\\+\\(?\\d{3}\\)?\\ \\d{3}\\-\\d{2}\\-\\d{2}", on = "save") })
	
	/** Represent a user. */
	private User user;

	/** Gets the user which being added. */
	public User getUser() {
		return user;
	}

	/** Sets the user which being added. */
	public void setUser(User user) {
		this.user = user;
	}

	/** DefaultHandler, which is called when the user arrives at the page for adding user. */
	@DefaultHandler
	public Resolution form() {
		return new ForwardResolution(FORM);
	}

	/** Handler that gets the values from input fields, adds user in database and
	 *  redirect them to the users list page.
	 */
	public Resolution save() {
		String surname = getContext().getRequest().getParameter("user.surname")
				.trim();
		String name = getContext().getRequest().getParameter("user.name")
				.trim();
		Integer age = Integer.valueOf(getContext().getRequest()
				.getParameter("user.age").trim());
		Character sex = getContext().getRequest().getParameter("user.sex")
				.charAt(0);
		String telephone = getContext().getRequest()
				.getParameter("user.telephone").trim();

		UserDaoImpl userDao = new UserDaoImpl();
		User newUser = new User();

		newUser.setSurname(surname);
		newUser.setName(name);
		newUser.setAge(age);
		newUser.setSex(sex);
		newUser.setTelephone(telephone);

		userDao.save(newUser);

		getContext().getMessages().add(
				new SimpleMessage("{0} has been saved.", newUser));
		return new RedirectResolution(UserListActionBean.class);
	}

	/** Handler that clears input fields on page for adding user. */
	@DontValidate
	public Resolution cancel() {
		return new RedirectResolution(UserListActionBean.class);
	}
}

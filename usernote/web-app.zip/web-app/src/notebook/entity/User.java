package notebook.entity;

/**
 * Represents a user in the database.
 * 
 */
public class User {
	/** Identifier of user. */
	private Integer id;
	
	/** Surname of user. */
	private String surname;
	
	/** Name of user. */
	private String name;
	
	/** Age of user. */
	private Integer age;
	
	/** Sex of user. */
	private Character sex;
	
	/** Telephone of user. */
	private String telephone;

	/** Gets the ID of the User. */
	public Integer getId() {
		return id;
	}

	/** Sets the ID of the User. */
	public void setId(Integer id) {
		this.id = id;
	}

	/** Gets the surname of the User. */
	public String getSurname() {
		return surname;
	}

	/** Sets the surname of the User. */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/** Gets the name of the User. */
	public String getName() {
		return name;
	}

	/** Sets the name of the User. */
	public void setName(String name) {
		this.name = name;
	}

	/** Gets the age of the User. */
	public Integer getAge() {
		return age;
	}

	/** Sets the age of the User. */
	public void setAge(Integer age) {
		this.age = age;
	}

	/** Gets the sex of the User. */
	public Character getSex() {
		return sex;
	}

	/** Sets the sex of the User. */
	public void setSex(Character sex) {
		this.sex = sex;
	}

	/** Gets the telephone of the User. */
	public String getTelephone() {
		return telephone;
	}

	/** Sets the telephone of the User. */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/** This method uses when comparing one object with another. */
	@Override
	public boolean equals(Object obj) {
		try {
			return id.equals(((User) obj).getId());
		} catch (Exception exc) {
			return false;
		}
	}

	/** This method uses when adding objects to collections. */
	@Override
	public int hashCode() {
		return 31 + ((id == null) ? 0 : id.hashCode());
	}

	/** This method displaying the user surname and name. */
	@Override
	public String toString() {
		return String.format("%s %s", surname, name);
	}
}

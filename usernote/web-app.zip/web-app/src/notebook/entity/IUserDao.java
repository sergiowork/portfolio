package notebook.entity;

import java.sql.SQLException;
import java.util.List;

/**
 * Manager class that is used to access a database of users that is tracked in memory.
 */
public interface IUserDao {
	/** 
	 * Returns a list of users from database. 
	 * @return The list of users.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	public List<User> read();
	
	/** 
	 * Returns a list of users found in database by criteria. 
	 * @param surname Surname of user.
	 * @param name Name of user.
	 * @param age Age of user.
	 * @param sex Sex of user.
	 * @param telephone Telephone of user.
	 * @return The list of users.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	public List<User> find(String surname, String name, Integer age, Character sex, String telephone);
	
	/** 
	 * Returns the user with the specified ID, or null if no such person exists. 
	 * @param id Identifier of user.
	 * @return The user.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	public User read(int id);
	
	/** 
	 * Stores the user in database. 
	 * @param user Instance of user.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	public void save(User user);
	
	/** 
	 * Updates the user in database. 
	 * @param user Instance of user.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	public void update(User user);
	
	/** 
	 * Deletes the user from the database. 
	 * @param id Identifier of user.
	 * @throws Exception if can't access to database data.
	 * @throws SQLException if can't close connection to database.
	 */
	public void delete(int id);
}

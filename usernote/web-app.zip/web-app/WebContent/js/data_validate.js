var surname;
var name;
var age;
var telephone;

function init() {
	surname = $("surnameId");
	name = $("nameId");
	age = $("ageId");
	telephone = $("telephoneId");
}

function validateForm() {
	valid = true;

	// checking surname
	if (surname.value.length <= 0) {
		alert("Don't leave the field Surname empty!");
		valid = false;
	} else if (surname.value.length < 5) {
		alert("Surname must be longer than 5 characters!");
		valid = false;
	} else if (surname.value.length > 30) {
		alert("Surname cannot exceed the length of 30 characters!");
		valid = false;
	}

	// checking name
	if (name.value.length <= 0) {
		alert("Don't leave the field Name empty!");
		valid = false;
	} else if (name.value.length < 5) {
		alert("Name must be longer than 5 characters!");
		valid = false;
	} else if (name.value.length > 15) {
		alert("Name cannot exceed the length of 15 characters!");
		valid = false;
	}


	// checking age
	if (age.value.length <= 0) {
		alert("Don't leave the field Age empty!");
		valid = false;
	} else if (isNaN(age.value)) {
		alert("Age must be a number!");
		valid = false;
	} else if (age.value == "0") {
		alert("Age cannot be a zero!");
		valid = false;
	}


	// checking telephone
	if (telephone.value.length <= 0) {
		alert("Don't leave the field Telephone empty!");
		valid = false;
	} else if (!(/^\+\([0-9]{3}\)\ [0-9]{3}\-[0-9]{2}\-[0-9]{2}/
			.test(telephone.value))) {
		alert("Invalid Telephone format! Expect +(xxx) xxx-xx-xx");
		valid = false;
	}

	return valid;
}


In build.properties you must specify properties for database connection. This file located in src folder.

For compile, create database, run Jetty and deploy web application you must 
unzip archive web-app.zip, go to directory web-app and follow steps below:

- compile source code and create web-app.war

ant

- create database

ant createdb

- run Jetty and deploy web application

ant run



OR to do one target:

ant all


The application will be accessible 
http://localhost:8080/
